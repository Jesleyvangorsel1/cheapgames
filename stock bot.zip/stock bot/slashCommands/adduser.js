const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('aduser')
        .setDescription('Add a user to the ticket channel'),
    async execute(interaction) {
        // Check if the command was used in a guild
        if (!interaction.member || !interaction.member.roles.cache.some(role => role.name === 'Wave Team')) {
            return interaction.reply('Only moderators can use this command.');
        }

        // Get the user who used the command
        const userToAdd = interaction.user;

        // Get the current channel
        const channel = interaction.channel;

        try {
            // Add the user to the channel
            await channel.permissionOverwrites.create(userToAdd, {
                VIEW_CHANNEL: true,
                SEND_MESSAGES: true,
            });

            interaction.reply(`Added ${userToAdd.tag} to this ticket.`);
        } catch (error) {
            console.error(`Error adding user to channel:`, error);
            interaction.reply(`An error occurred while adding the user to this channel.`);
        }
    },
};
