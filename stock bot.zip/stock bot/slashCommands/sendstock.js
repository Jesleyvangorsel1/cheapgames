const fs = require('fs');
const { SlashCommandBuilder } = require('discord.js');

const STOCK_FILE_PATHS = {
    'nitrobst': './nitrobst.txt',
    'nitrobasic': './nitrobasic.txt',
    '3mtokens': './3mtokens.txt',
    '1mtokens': './1mtokens.txt'
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sendstock')
        .setDescription('Send stock to a user')
        .addStringOption(option =>
            option.setName('item')
                .setDescription('Select the item to send from')
                .setRequired(true)
                .addChoices(
                    { name: 'Nitro Bst', value: 'nitrobst' },
                    { name: 'Nitro Basic', value: 'nitrobasic' },
                    { name: '3M Tokens', value: '3mtokens' },
                    { name: '1M Tokens', value: '1mtokens' }
                ))
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Amount of items to send')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to send the stock to')
                .setRequired(true)),
    async execute(interaction) {
        const itemName = interaction.options.getString('item');

        if (!STOCK_FILE_PATHS[itemName]) {
            return interaction.reply(`Item "${itemName}" is not restockable.`);
        }

        const amount = interaction.options.getInteger('amount');
        if (!amount || amount <= 0) {
            return interaction.reply('Please provide a valid positive amount.');
        }

        const user = interaction.options.getUser('user');
        if (!user) {
            return interaction.reply('Please provide a valid user.');
        }

        const filePath = STOCK_FILE_PATHS[itemName];

        try {
            const currentData = fs.readFileSync(filePath, 'utf-8');
            const lines = currentData.trim().split('\n');
            const sentItems = lines.slice(0, amount);

            if (sentItems.length === 0) {
                return interaction.reply('Not enough items in stock to send.');
            }

            const restockData = lines.slice(amount).join('\n');
            fs.writeFileSync(filePath, restockData);

            const sentItemsText = sentItems.join('\n');
            await user.send(`Here are your ${itemName}(s):\n${sentItemsText}`);
            interaction.reply(`Sent ${amount} ${itemName}(s) to ${user.tag}.`);
        } catch (error) {
            console.error(`Error sending stock to ${user.tag}:`, error);
            interaction.reply(`An error occurred while sending stock to ${user.tag}.`);
        }
    },
};
