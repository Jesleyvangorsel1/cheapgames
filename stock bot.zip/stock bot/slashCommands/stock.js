const fs = require('fs');
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const STOCK_FILE_PATHS = ['./nitrobst.txt', './nitrobasic.txt', './3mtokens.txt', './1mtokens.txt'];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stock')
        .setDescription('Check stock for specific items'),
    async execute(interaction) {
        const stock = {};

        STOCK_FILE_PATHS.forEach(filePath => {
            try {
                const data = fs.readFileSync(filePath, 'utf-8');
                const lines = data.trim().split('\n');

                lines.forEach(line => {
                    if (line.trim() !== '') {
                        stock[filePath] = (stock[filePath] || 0) + 1;
                    }
                });
            } catch (error) {
                console.error(`Error reading file ${filePath}:`, error);
            }
        });
        const { guild } = interaction;
        const icon = guild.iconURL() || 'https://media.discordapp.net/attachments/1142430822864007239/1142437033445425202/IMG_2634.jpg?width=692&height=692'

        const embed = new EmbedBuilder()
            .setTitle('Stock Information')
            .setThumbnail(icon)
            .setFooter({text:`Stock - Cheap Games` })
            .setColor('#2596be');
            

        const fields = STOCK_FILE_PATHS.map(filePath => {
            const fileName = filePath.slice(2, -4); // Remove './' from the beginning and '.txt' from the end
            const stockCount = stock[filePath] || 0;
            return { name: fileName, value: `Stock: ${stockCount}`, inline: true };
        });

        embed.addFields(
            { name: 'Stock Information', value: 'Here is the stock information:' },
            ...fields
        );

        interaction.reply({ embeds: [embed] });
    },
};
