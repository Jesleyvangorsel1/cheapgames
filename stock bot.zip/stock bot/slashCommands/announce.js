const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('announce')
        .setDescription('Send an announcement')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Select the channel')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Enter the announcement title')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('message')
                .setDescription('Enter the announcement message')
                .setRequired(true)),
    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');
        const title = interaction.options.getString('title');
        const messageContent = interaction.options.getString('message');
        const { guild } = interaction;
        const icon = guild.iconURL() || 'https://media.discordapp.net/attachments/1142430822864007239/1142437033445425202/IMG_2634.jpg?width=692&height=692'
        const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription(messageContent)
            .setColor('#2596be')
            .setThumbnail(icon)
            .setFooter({ text: 'Cheap Games', iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp();

        await channel.send({ embeds: [embed] });

        await interaction.reply('Announcement sent successfully.');
    },
};
