const fs = require('fs');
const { SlashCommandBuilder } = require('discord.js');

const STOCK_FILE_PATHS = {
    'nitrobst': './nitrobst.txt',
    'nitrobasic': './nitrobasic.txt',
    '3mtokens': './3mtokens.txt',
    '1mtokens': './1mtokens.txt'
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('deletestock')
        .setDescription('Delete items from stock')
        .addStringOption(option =>
            option.setName('item')
                .setDescription('Select the item to delete from')
                .setRequired(true)
                .addChoices(
                    { name: 'Nitro Bst', value: 'nitrobst' },
                    { name: 'Nitro Basic', value: 'nitrobasic' },
                    { name: '3M Tokens', value: '3mtokens' },
                    { name: '1M Tokens', value: '1mtokens' }
                ))
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Amount of items to delete')
                .setRequired(true)),
    async execute(interaction) {
        const itemName = interaction.options.getString('item');
     if (!interaction.member || !interaction.member.roles.cache.some(role => role.name === 'Wave Team')) {
            return interaction.reply('Only moderators can use this command.');
     }
        if (!STOCK_FILE_PATHS[itemName]) {
            return interaction.reply(`Item "${itemName}" is not restockable.`);
        }

        const amount = interaction.options.getInteger('amount');
        if (!amount || amount <= 0) {
            return interaction.reply('Please provide a valid positive amount.');
        }

        const filePath = STOCK_FILE_PATHS[itemName];

        try {
            const currentData = fs.readFileSync(filePath, 'utf-8');
            const lines = currentData.trim().split('\n');
            lines.splice(0, amount);

            fs.writeFileSync(filePath, lines.join('\n'));
            interaction.reply(`Deleted ${amount} ${itemName}(s).`);
        } catch (error) {
            console.error(`Error deleting from ${itemName}:`, error);
            interaction.reply(`An error occurred while deleting from ${itemName}.`);
        }
    },
};
