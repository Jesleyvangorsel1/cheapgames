const fs = require('fs');
const { SlashCommandBuilder } = require('discord.js');

const STOCK_FILE_PATHS = {
    'nitrobst': './nitrobst.txt',
    'nitrobasic': './nitrobasic.txt',
    '3mtokens': './3mtokens.txt',
    '1mtokens': './1mtokens.txt'
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('restock')
        .setDescription('Restock items')
        .addStringOption(option =>
            option.setName('item')
                .setDescription('Select the item to restock')
                .setRequired(true)
                .addChoices(
                    { name: 'Nitro Bst', value: 'nitrobst' },
                    { name: 'Nitro Basic', value: 'nitrobasic' },
                    { name: '3M Tokens', value: '3mtokens' },
                    { name: '1M Tokens', value: '1mtokens' }
                ))
        .addStringOption(option =>
            option.setName('items')
                .setDescription('Items to restock (separated by spaces)')
                .setRequired(true)),
    async execute(interaction) {
        const itemName = interaction.options.getString('item');
     if (!interaction.member || !interaction.member.roles.cache.some(role => role.name === 'Wave Team')) {
            return interaction.reply('Only moderators can use this command.');
     }
        if (!STOCK_FILE_PATHS[itemName]) {
            return interaction.reply(`Item "${itemName}" is not restockable.`);
        }

        const items = interaction.options.getString('items').split(' ');
        const restockData = items.join('\n');

        const filePath = STOCK_FILE_PATHS[itemName];

        try {
            const currentData = fs.readFileSync(filePath, 'utf-8');
            fs.writeFileSync(filePath, `${restockData}\n${currentData}`);
            interaction.reply(`Restocked ${items.length} ${itemName}(s).`);
        } catch (error) {
            console.error(`Error restocking ${itemName}:`, error);
            interaction.reply(`An error occurred while restocking ${itemName}.`);
        }
    },
};
