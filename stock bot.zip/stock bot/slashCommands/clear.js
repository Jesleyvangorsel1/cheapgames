const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
    category: "moderation",
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Delete some messages from the current channel.')
        .addIntegerOption(option => 
            option.setName('number')
            .setDescription('How many messages would you like to delete? (max 100)')
            .setRequired(true)),

    async execute(interaction) {
        
        if (!interaction.member || !interaction.member.roles.cache.some(role => role.name === 'Wave Team')) {
            return interaction.reply('Only moderators can use this command.');
        }

        const aantal = interaction.options.getInteger('aantal');

        // Controleren of het aantal berichten minder is dan 100.
        if (number > 100) {
            return interaction.reply('The number of messages you want to delete cannot exceed 100.');
        }

        // Verwijderen van de berichten.
        await interaction.channel.bulkDelete(aantal, true)
            .catch(error => {
                console.error(error);
                interaction.reply(`An error occurred while deleting ${number} of messages.`);
            });

        interaction.reply(`There were ${number} of messages deleted.`);
    }
};
