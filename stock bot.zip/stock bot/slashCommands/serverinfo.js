const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('serverinfo')
        .setDescription('Displays information from the server.'),
    async execute(interaction) {
        const { guild } = interaction;
        const { name, ownerId, createdTimestamp, memberCount } = guild;
        const roles = guild.roles.cache.size;
        const emojis = guild.emojis.size;
        const id = guild.id;
        const icon = guild.iconURL() || 'https://media.discordapp.net/attachments/1142430822864007239/1142437033445425202/IMG_2634.jpg?width=692&height=692'
        const embed = new EmbedBuilder()
            .setColor('#2596be')
            .setAuthor({ name: name, iconURL: icon })
            .setFooter({ text: `Server ID ${id}` })
            .setThumbnail(icon)
            .setTimestamp()
            .addFields({ name: "Servername", value: `${name}`, inline: false })
            .addFields({ name: "Server date", value: `<t:${parseInt(createdTimestamp / 1000)}:R>`, inline: true })
            .addFields({ name: "Server owner", value: `${ownerId}`, inline: true })
            .addFields({ name: "Server members", value: `${memberCount}`, inline: true })
            .addFields({ name: "Roles", value: `${roles}`, inline: true })
            .addFields({ name: "Emojis", value: `${emojis}`, inline: true })
            .addFields({ name: "Server Boosts", value: `${guild.premiumSubscriptionCount}`, inline: true });

        await interaction.reply({ embeds: [embed] });
    },
};
