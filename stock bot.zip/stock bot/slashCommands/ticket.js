const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionFlagsBits, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('new-ticket')
        .setDescription('soon*')
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
    async execute(interaction) {
             if (!interaction.member || !interaction.member.roles.cache.some(role => role.name === 'Wave Team')) {
            return interaction.reply('Only moderators can use this command.');
             }
        const embed = new EmbedBuilder()
            .setTitle('Cheap Games Ticket')
            .setDescription('Create a ticket by selecting a subject in the dropdown menu.')
            .setColor('#03befc')
            .setFooter({text: 'Cheap Games'})
            .setTimestamp();

const select = new StringSelectMenuBuilder()
			.setCustomId('starter')
			.setPlaceholder('Create ticket.')
			.addOptions(
				new StringSelectMenuOptionBuilder()
                   
					.setLabel('Purchase')
					.setDescription('Make this ticket if you want to purchase somthing')
					.setValue('Purchase'),
				new StringSelectMenuOptionBuilder()
                    
					.setLabel('Support')
					.setDescription('Make this ticket if you need support.')
					.setValue('Support'),
                	new StringSelectMenuOptionBuilder()
                  
					.setLabel('Giveaway Claim')
					.setDescription('Make this ticket if you won a giveaway.')
					.setValue('Giveaway Claim'),
                
                
	
			);


        const row = new ActionRowBuilder()
            .addComponents(select);
            await interaction.guild.channels.cache.find(n => n.name.toLowerCase() === "algemeen").send({ embeds: [embed], components: [row] });

    
    }
};
