const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Show available commands'),
    async execute(interaction) {
        try {
            const commandFiles = fs.readdirSync(path.join(__dirname, '..', 'slashCommands')).filter(file => file.endsWith('.js'));
            const { guild } = interaction;
const icon = guild.iconURL() || 'https://media.discordapp.net/attachments/1142430822864007239/1142437033445425202/IMG_2634.jpg?width=692&height=692'

            const embed = new EmbedBuilder()
                .setTitle('Command List')
                .setDescription('Here is a list of available commands:')
                .setThumbnail(icon)
                .setColor('#2596be')
                .setTimestamp();

            for (const file of commandFiles) {
                const command = require(`../slashCommands/${file}`);
                embed.addFields({ name: `/${command.data.name}`, value: command.data.description, inline: true });
            }

            embed.setFooter({ text: 'Cheap Games', iconURL: interaction.guild.iconURL({ dynamic: true }) });

            await interaction.reply({ embeds: [embed], ephemeral: false });
        } catch (error) {
            console.error(error);
            await interaction.reply('Error.');
        }
    },
};
