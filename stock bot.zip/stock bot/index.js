const { Client, GatewayIntentBits, Routes, Collection, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionFlagsBits, ModalBuilder, Events, TextInputBuilder, TextInputStyle, ChannelTypeManager, Permissions, PermissionsBitField, ChannelType } = require("discord.js");
const botConfig = require("./botConfig.json");
const fs = require("node:fs");
const { REST } = require("@discordjs/rest");
const path = require('path');


const client = new Client({ intents: [GatewayIntentBits.Guilds] });
client.commands = new Collection();
const slashCommands = [];


client.once("ready", () => {
  client.user.setActivity('op je lekkere kanker hoere moeder😘');
  console.log(`${client.user.username} is online.`);

  let guildId = botConfig.guildID;
  let clientId = botConfig.clientID;
  let token = botConfig.token;
  const rest = new REST({ version: 10 }).setToken(token);
  rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: slashCommands })
    .then(() => console.log('Applicatie commandos geregristreerd.'))
    .catch(console.error);

});

const commandsPath = path.join(__dirname, 'slashCommands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  client.commands.set(command.data.name, command);
  slashCommands.push(command.data.toJSON());
  console.log(`De file ${command.data.name}.js is geladen`);

}
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const command = client.commands.get(interaction.commandName);
  if (!command) return;
  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(error);
    await interaction.reply({ content: 'Error', ephemeral: true });
  }

})


client.login(botConfig.token);




var tickets = [];

client.on('interactionCreate', async (interaction) => {
  if (interaction.isStringSelectMenu() && interaction.customId == 'starter') {
    const modal = new ModalBuilder()
      .setCustomId('ticketModal')
      .setTitle('Support Ticket');
    const topicInput = new TextInputBuilder()
      .setCustomId('topic')
      .setLabel('Topic')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('What is the subject of the ticket? e.g. (purchases, questions, etc)')
      .setMinLength(3)
      .setMaxLength(25)
      .setRequired(true);
    const issueInput = new TextInputBuilder()
      .setCustomId('issue')
      .setLabel('Issue')
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder('Please provide further details e.g. ( I want to buy 1x nordvpn 1 year or your question)')
      .setMinLength(5)
      .setMaxLength(250)
      .setRequired(true);

    const firstActionRow = new ActionRowBuilder().addComponents(topicInput);
    const secondActionRow = new ActionRowBuilder().addComponents(issueInput);
    modal.addComponents(firstActionRow, secondActionRow);
    await interaction.showModal(modal);
  } else if (interaction.isModalSubmit()) {
    const topic = interaction.fields.getTextInputValue('topic');
    const issue = interaction.fields.getTextInputValue('issue');
    const { ChannelType } = require('discord.js');
    const guild = interaction.guild;
    const channel = await guild.channels.create({
      name: `${interaction.user.username}-ticket`,
      type: ChannelType.GuildText,
      parent: '1139915593261260812',
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          deny: [PermissionsBitField.Flags.ViewChannel],
        },
          
          {
          id: interaction.user.id,
          allow: [PermissionsBitField.Flags.ViewChannel], // Allow the creator to view the channel
        },
        {
          id: '1103772240878776450', // ROLE ID VOOR STAFF
          allow: [PermissionsBitField.Flags.ViewChannel],
        },
      ],
    });

    const embed = new EmbedBuilder()
      .setTitle(`<:emoji_52:1135172911989268592> Ticket - ${interaction.user.tag}`)
      .setDescription('>>> *Ticket created, waiting for staff team to respond. Please put further details here in advance.*')
      .setTimestamp()
      .setColor('#2596be')
      .setFooter({ text: `Ticket created at` })
      .addFields(
        { name: 'User', value: ` >>> ${interaction.user.username}` },
        { name: 'Topic', value: ` >>> ${topic}` },
        { name: 'Details', value: ` >>> ${issue}` }
      );

    const closeBtn = new ButtonBuilder()
     
      .setLabel('Close Ticket')
      .setStyle(ButtonStyle.Secondary)
      .setCustomId('closeTicket');

    const claimbtn = new ButtonBuilder()
     
      .setLabel('Claim Ticket')
      .setStyle(ButtonStyle.Secondary)
      .setCustomId('ClaimTicket');

    const row = new ActionRowBuilder().addComponents(closeBtn, pingBtn, claimbtn);
    await channel.send({ embeds: [embed], components: [row] });

    await interaction.reply({
      content: `${interaction.user.tag}, your ticket has been successfully created in ${channel}`,
      ephemeral: true,
    });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton() && interaction.customId == 'closeTicket') {
    delete tickets[interaction.user.id];
    interaction.channel.delete();

    const dmEmbed = new EmbedBuilder()
      .setTitle('Ticket Closed')
      .setDescription('>>> You successfully closed the ticket')
      .setColor('#03befc')
      .setTimestamp()
      .setFooter({ text: `Sent from ${interaction.guild.name}` });

    const dmButton = new ButtonBuilder()
      .setLabel('Check logs')
      .setStyle(ButtonStyle.Link)
      .setURL('https://discord.com/channels/1037945790271848529/1106803412336660570');

    const dmRow = new ActionRowBuilder().addComponents(dmButton);

    await interaction.user.send({ embeds: [dmEmbed], components: [dmRow] });
    return;
  }
});





client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton() && interaction.customId === 'ClaimTicket') {
    const embed = new EmbedBuilder()
      .setTitle('Ticket Claimed')
      .setDescription(`>>> Ticket Claimed by ${interaction.user.tag}`)
      .setColor('#03befc')
      .setTimestamp()
      .setFooter({ text: 'Ticket claimed at' }) 

    await interaction.channel.send({ embeds: [embed] });

    await interaction.reply({
      content: 'You claimed the ticket.',
      ephemeral: true
    });
  }
});


